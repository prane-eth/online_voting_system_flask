# pythonanywhere.com     vitapele   vitapele@guerrillamail.com      vitap123       vitapele.pythonanywhere.com

# https://tailwind.run/new
# https://www.pythonanywhere.com/user/vitapele/files/home/vitapele/mysite/flask_app.py?edit

#from flask import Flask, render_template, request
from flask import Flask, request, redirect, session, render_template, render_template_string
from os import system


class var:
    login_html = '''
        <html>
        	<head>
        		<title> Login </title>
                <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        	</head>
        	<body>
        	    </br></br></br></br></br></br></br>

        		<div align="center" class="border">
        			<div class="header">
        				<h1 class="word">Login</h1>
        				Fake login page by 18BCE7147 for experimental uses
        			</div>
        			</br></br></br>
        			<h2 class="word">
        				<form action="/login" method="post">
            				<div class="msg"> {{ msg }} </div>
        					<input id="email" name="email" type="text" placeholder="Enter Your Email" class="textbox" value="18BCE7147@test.com" />
        					</br></br>
        					<input id="password" name="password" type="password" placeholder="Enter Your Password" class="textbox" value="password123" />
        					</br></br></br>
        					<input type="submit" class="btn" value="Sign In">
        					</br></br>
        				</form>
        			</h2>
        		</div>

        	</body>
        </html>
    '''


app = Flask(__name__)
app.secret_key = 'my_secret_key'
# system("python3 ./result.py")

@app.route('/')
def home_page():
    return render_template("home.html")


@app.route('/register')
def register():
    return render_template("register.html")


@app.route('/vote')
def vote():
    return render_template("vote.html", image_name="votes.jpg")
# Change "contestant" to candidate
# Add CPI to image
# https://www.bing.com/images/search?q=Muppala+nageswara+rao+CPI


@app.route('/feedback')
def feedback():
    return render_template("feedback.html")


@app.route('/thank', methods=['GET', 'POST'])
def feedt():
    if request.method == 'POST':
        result = request.form
        feedback = request.form.to_dict(result)["feedback"]+' '+request.form.to_dict(result)["experience"]
        system("echo '" + str(feedback) + "' >> mysite/feedback.txt")
        return render_template("thank.html")


@app.route('/reg_done', methods=['GET', 'POST'])
def reg_done():
    if request.method == 'POST':
        result = request.form
        resp = request.form.to_dict(result)["a_num"]+' '+request.form.to_dict(result)["b_year"] #+' '+request.form.to_dict(result)["name"]
        system("echo '" + str(resp) + "' >> mysite/reg_data.txt")
        return render_template("reg_done.html")


@app.route('/vote_done', methods=['GET', 'POST'])
def vote_done():
    if request.method == 'POST':
        result = request.form
        vote = request.form.to_dict(result)["vote"] + ' ' + request.form.to_dict(result)["a_num"]
        system("echo '" + str(vote) + "' >> mysite/vote_data.txt")
        return render_template("vote_done.html")

@app.route('/result')
def result():
    return render_template("result.html", image_name="res.jpg")


@app.route('/login', methods =['GET', 'POST'])
def login():
    msg = ''
    if request.method == 'POST' and 'email' in request.form and 'password' in request.form:
        email = request.form['email']
        #password = request.form['password']
        # print(email, password)
        session['loggedin'] = True
        session['id'] = email
        session['email'] = email
        msg = 'Logged in successfully !'
        return redirect('/index')
    return render_template_string(var.login_html, msg=msg)


if __name__ == '__main__':
    app.run()




